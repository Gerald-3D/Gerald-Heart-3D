#include <iostream>
#include <fstream>
#include <cmath>
#include "CIsoSurface.h"
#include <GL/glut.h>
#include <iomanip>
#include <math.h>
#include <new>
#include "importOBJ.h"
#include "GetVerticesNormals.h"
#include <utility>

extern "C" {
#include "f2c.h"
#include "clapack.h"
}

using namespace std;

float f1(float _x, float _y, float _z);
float D3(float x_, float y_, float z_, float h3, int count3);
float *charge;
float *phi3;

int triangles = 0;

// START INITIALIZATION FROM MC
int lines_faces = 0, lines_faces1 = 0;

int z = 0, num = 0, c1 = 0, n = 0, n1 = 0, n2 = 0, m = 0;

float phi[8000][8000];
float dv[8000][8000];
float dv1[8000][8000];
float dv2[8000][8000];
float dv3[8000][8000];
float aLU[8000][8000];

float dsc = 0.0f;
float x0_ = 0, x1_ = 0, y0_ = 0, y1_ = 0;

//START FACES AND VERTEX AND FUNCTIONS
GLdouble vertex[1000000][3] = {
	//{ /*-0.57735,-0.57735, 0.57735*/ },
	/*{ 0.934172,  0.356822,  0 },
	{ 0.934172, -0.356822,  0 },
	{ -0.934172,  0.356822,  0 },
	{ -0.934172, -0.356822,  0 },
	{ 0, 0.934172,  0.356822 },
	{ 0,0.934172, -0.356822 },
	{ 0.356822,  0, -0.934172 },
	{ -0.356822,  0, -0.934172 },
	{ 0,-0.934172, -0.356822 },
	{ 0,-0.934172,  0.356822 },
	{ 0.356822,  0,  0.934172 },
	{ -0.356822,  0, 0.934172 },
	{ 0.57735,  0.57735, -0.57735 },
	{ 0.57735,  0.57735,  0.57735 },
	{ -0.57735,  0.57735, -0.57735 },
	{ -0.57735,  0.57735,  0.57735 },
	{ 0.57735, -0.57735, -0.57735 },
	{ 0.57735, -0.57735,  0.57735 },
	{ -0.57735, -0.57735, -0.57735 }*/
};



int face[1000000][3] = {
	//{/* 18,  2,  1*/ },
	//{ 11,  18,1 },
	//{ 14,11,  1 },
	//{ 7,  13,  1 },
	//{ 17,  7,  1 },
	//{ 2, 17,  1 },
	//{ 19,  4,  3 },
	//{ 8,  19,  3 },
	//{ 15,  8,  3 },
	//{ 12,  16,  3 },
	//{ 0,  12,  3 },
	//{ 4,  0,  3 },
	//{ 6,  15,  3 },
	//{ 5,  6,  3 },
	//{ 16,  5,  3 },
	//{ 5,  14,  1 },
	//{ 6,  5,  1 },
	//{ 13,  6,  1 },
	//{ 9,  17,  2 },
	//{ 10,  9,  2 },
	//{ 18,  10,  2 },
	//{ 10,  0,  4 },
	//{ 9,  10,  4 },
	//{ 19,  9,  4 },
	//{ 19,  8,  7 },
	//{ 9,  19,  7 },
	//{ 17,  9,  7 },
	//{ 8,  15,  6 },
	//{ 7,  8,  6 },
	//{ 13,  7,  6 },
	//{ 11,  14,  5 },
	//{ 12,  11,  5 },
	//{ 16,  12,  5 },
	//{ 12,  0,  10 },
	//{ 11,  12, 10 },
	//{ 18,  11,  10 }

};

//END FACES AND VERTEX AND FUNCTIONS

float DistanceSquaredCube3D(float x0, float y0, float z0, float x1, float y1, float z1) {
	dsc = (x0 - x1)*(x0 - x1) + (y0 - y1)*(y0 - y1) + (z0 - z1)*(z0 - z1);
	dsc = (sqrt(dsc))*(sqrt(dsc))*(sqrt(dsc));
	return dsc;
}

int main(int argc, char ** argv) {

	string filename2 = "Heart3D.obj"; 
	vector<Pt2> vertices2;
	vector<Triangle2> triangles2;

	readFile(filename2, vertices2, triangles2);                   // Read //vertices and triangles
	calcFaces(vertices2, triangles2);                            // Calculate //area vectors for triangles
	summary(vertices2, triangles2);                              // Check

	vector<Pt2> vnormal = calcNormals(vertices2, triangles2);     // Calculate //normals at vertices

	//Testing if vertices2 will print out!
	int count_vertices2 = 0;
	for (Pt2 p : vertices2)
	{
		//temp cout << "\nVertices2: ";
		dv1[count_vertices2][0] = p.x;
		//temp cout<< p.x<<" ";
		dv1[count_vertices2][1] = p.y;
		//temp cout << p.y<<" ";
		dv1[count_vertices2][2] = p.z;
		//temp cout << p.z<<" \n";
		count_vertices2++;

	}
	//Testing if vnormals will print out!
	int count_vnormal = 0;
	for (Pt2 p : vnormal)
	{
		//temp cout << "\nVnormals: ";
		dv2[count_vnormal][0] = p.x;
		//temp cout << p.x << " ";
		dv2[count_vnormal][1] = p.y;
		//temp cout << p.y << " ";
		dv2[count_vnormal][2] = p.z;
		//temp cout << p.z << " \n";
		count_vnormal++;
	}
	float offset = 1; //distance between the original and offset point.

	for (int x = 0; x < count_vnormal; x++) {
		dv3[x][0] = dv1[x][0] - offset*(dv2[x][0]);
		dv3[x][1] = dv1[x][1] - offset*(dv2[x][1]);
		dv3[x][2] = dv1[x][2] - offset*(dv2[x][2]);
		//cout << dv3[x][0] << "="<< dv1[x][0]<<" - "<<offset*dv2[x][0]<<endl;
		//cout <<  dv3[x][1] << "=" << dv1[x][1] << " - " << offset*dv2[x][1] << endl;
		//cout << dv3[x][2] << "=" << dv1[x][2] << " - " << offset*dv2[x][2] <<endl<<endl;
		//temp cout /*<< x*/ <<"v "<< dv3[x][0] << " " << dv3[x][1] << " " << dv3[x][2] << endl;
	}

	int point = 0;

	for (Pt2 p : vertices2) 
	{
		dv[point][0] = p.x;
		dv[point][1] = p.y;
		dv[point][2] = p.z;
		dv[point][count_vnormal*2+4] = 0.0;
		//cout << dv[point][0] << "  " << dv[point][1] << "  " << dv[point][2] << "  "<< dv[point][2732]<< '\n';
		
		point++;
	}
	n = count_vnormal*2; //times 2 because I ignored the point and getFacesAndVertices
	
	for (int i = 0; i < count_vnormal; i++) {

		dv[i + count_vnormal][0] = dv3[i][0]; //equating dv-th value after the 112th! which means the offset constraints!
		dv[i + count_vnormal][1] = dv3[i][1]; //equating dv-th value after the 112th! which means the offset constraints!
		dv[i + count_vnormal][2] = dv3[i][2]; //equating dv-th value after the 112th! which means the offset constraints!
		dv[i + count_vnormal][count_vnormal * 2 + 4] = sqrt((dv[i][0] - dv3[i][0])*(dv[i][0] - dv3[i][0]) + (dv[i][1] - dv3[i][1])*(dv[i][1] - dv3[i][1]) + (dv[i][2] - dv3[i][2])*(dv[i][2] - dv3[i][2]));
		//temp cout << "New Distance: " << dv[i + count_vnormal][count_vnormal * 2 + 4] << endl;
	}
	
	int a1 = 0;
	for (int x = 0; x < n; x++) {
		for (int y = 0; y < n; y++) {
			float x0_ = dv[a1][0];
			float y0_ = dv[a1][1];
			float z0_ = dv[a1][2];
			float x1_ = dv[y][0];
			float y1_ = dv[y][1];
			float z1_ = dv[y][2];
			//cout << "Displayed SquareRoot Cube:" << "[" << x0_ << "][" << y0_ << "][" << z0_ << "] AND [" << x1_ << "]" << "[" << y1_ << "][" << z1_ << "]" << DistanceSquaredCube3D(x0_, y0_, z0_, x1_, y1_, z1_) << endl;
			phi[x][y] = DistanceSquaredCube3D(x0_, y0_, z0_, x1_, y1_, z1_);
		}
		a1++;
	}

	n = n + 4;
	int b = n - 3;
	int d = n - 2;
	int p1 = n - 1;
	int f = n - 3;
	int h = n - 2;
	int r1 = n - 1;


	//Creating the Matrix of Phi. 
	for (int x = 0; x < n; x++) {
		for (int y = 0; y < n; y++) {


			if (x >= n - 4) {
				if (y >= n - 4) {
					phi[x][y] = 0; 
				}
			}
			if (((x == n - 4) && (y < n - 4)) || ((x < n - 4) && (y == n - 4))) {
				phi[x][y] = 1;   
			}
			//for phi 50 51 52 53 index
			if ((x == n - 3) && (y < n - 4)) {
				int c = x - b;
				phi[x][c] = dv[c][0]; 
				b--;
			}
			//for phi 60 61 62 63 index
			if ((x == n - 2) && (y < n - 4)) {
				int e = x - d;
				phi[x][e] = dv[e][1]; 
				d--;
			}
			//for phi 70 71 71 73 ...
			if ((x == n - 1) && (y < n - 4)) {
				int q = x - p1;
				phi[x][q] = dv[q][2]; 
				p1--;
			}

			//for phi 05 15 25 35 index
			if ((x < n - 4) && (y == n - 3)) {
				int g = y - f;
				phi[g][y] = dv[g][0]; 
				f--;
			}
			////for phi 06 16 26 36 index
			if ((x < n - 4) && (y == n - 2)) {
				int i1 = y - h;
				phi[i1][y] = dv[i1][1]; 
				h--;
			}
			// for phi 07 17 27 37 
			if ((x < n - 4) && (y == n - 1)) {
				int s = y - r1;
				phi[s][y] = dv[s][2];  
				r1--;
			}
		}
		//cout << "]" << endl;
	}
	n1 = n - 4;
	for (n1; n1<n; n1++) {
		dv[n1][n] = 0;
		//cout << n1;
	}
	

	phi3 = new float[1000000];
	int count_phi = 0;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			/*cin >> aLU[i][j];*/
			phi3[count_phi]= phi[i][j];
			count_phi++;
			
		}

	}
	//for exampple 4x4 
	//a[0][0] = 0.0f; a[0][1] = 1.0f; a[0][2] = 2.0f; a[0][3] = 4.0f;
	//a[1][0] = 1.0f; a[1][1] = 0.0f; a[1][2] = 1.0f; a[1][3] = 5.0f;
	//a[2][0] = 2.0f; a[2][1] = 1.0f; a[2][2] = 0.0f; a[2][3] = 6.0f;
	//a[3][0] = 2.0f; a[3][1] = 1.0f; a[3][2] = 9.0f; a[3][3] = 7.0f;

	//temp cout << "Enter the elements of b:\n";
	// Elements of b
	// Caution! The elements should be stored
	// at (a[0][n], a[1][n], a[2][n], ..., a[n - 1][n] )


	for (int i = 0; i < n; i++) {
		/*cin >> aLU[i][n];*/
		aLU[i][n] = dv[i][n];
	}
	//for example 4x4 
	//a[0][4] = 6.0f;
	//a[1][4] = 2.0f;
	//a[2][4] = 8.0f;
	//a[3][4] = 4.0f;


	//temp cout << "Linear system: Ax=b\n\n";
	//temp cout << "Size of matrix: " << n << "\n\n";
	//temp cout << "Matrix A =\n";
	//for (int i = 0; i < n; i++) { //comment out if not printing matrix and vectors!
	//	for (int j = 0; j < n; j++) {
	//		//cout << aLU[i][j] << "\t";

	//	}
	//	//cout << "\n";
	//}
	//cout << "\nVector b =\n";
	//for (int i = 0; i < n; i++) {
	//	//cout << aLU[i][n] << "\n";
	//}


	//{START} Additional charge array for SGESV later!
	charge = new float[100000];
	for (int i = 0; i < n; i++) {
		/*cin >> aLU[i][n];*/
		charge[i] = dv[i][n];
	}
	//{END} Additional charge array for SGESV later!

	//{START}TRY SGESV method!
	//cout << "value of n now" << n;
	int nrhs = 1;
	int* ipiv = new int[n];
	int info;
	sgesv_((integer*)&n, (integer*)&nrhs, (real*)phi3, (integer*)&n, (integer*)ipiv, (real*)charge, (integer*)&n, (integer*)&info);
	//cout << "Solution using SGESV!";
	//for (int i = 0; i < n; i++) {
	//	cout << "aLU[i][n]: " << aLU[i][n] << "\t" << " charge[i]: "<<charge[i] << "\n";
	//}
	//{END} TRY SGESV method!

	float s = 0.0f, s1 = 0.0f;

	float manual_range = 100.0;
	//******************************************************************************************Start from Marching Cubes code //******************************************************************************************
	//editing these values will have a narrow 3D clipping coordinates?
	const float range[6] = { -manual_range, manual_range, -manual_range, manual_range, -manual_range, manual_range }; //it doesn't matter in the range... this needs to change only for the boundaries!
	//the higher the value of nCells, the finer is the surface?
	const unsigned int nCells = 60;
	const unsigned int nSamp = nCells + 1;
	//this is the size of the cells?
	float hX = (range[1] - range[0]) / (float)nCells;
	//std::cout << hX  << " = (" << range[1] << " - " << range[0] << ")/" << (float)nCells << "\n";
	float hY = (range[3] - range[2]) / (float)nCells;
	//std::cout << hY << " = (" << range[3] << " - " << range[2] << ")/" << (float)nCells << "\n";
	float hZ = (range[5] - range[4]) / (float)nCells;
	//std::cout << hZ << " = (" << range[5] << " - " << range[4] << ")/" << (float)nCells << "\n";
	int numCells = n - 4;
	// Start sampling
	float* V = new float[nSamp * nSamp * nSamp];
	for (unsigned int i = 0; i < nSamp; i++) {
		float x = range[0] + hX * i; 
		for (unsigned int j = 0; j < nSamp; j++) {
			float y = range[2] + hY * j; 
			for (unsigned int k = 0; k < nSamp; k++) {
				float z = range[4] + hZ * k; 
				setprecision(15);
				// Store (i, j, k)-th value to
				// [i + j * nSamp + k * nSamp * nSamp]
				V[i + (j * nSamp) + (k * nSamp * nSamp)]
					= f1(x, y, z); 
			}
		}

	}
	
	// Retrieve isosurface
	CIsoSurface<float>* isosurf = new CIsoSurface<float>(); //it has the same pattern as initializing a DYNAMIC array!
	isosurf->GenerateSurface(V, 0.0f, nCells, nCells, nCells, hX, hY, hZ); //void GenerateSurface(const T* ptScalarField, T tIsoLevel, unsigned int nCellsX, unsigned int nCellsY,  unsigned int nCellsZ, float fCellLengthX, float fCellLengthY, float fCellLengthZ);
	delete[] V;
	
	std::ofstream ofs;
	ofs.open("Gerald's Heart 3D.obj");

	GLdouble is_a = 0.0, is_b = 0.0, is_c = 0.0;
	for (unsigned int i = 0;
		i < isosurf->getNVertices(); i++) {
		ofs << "v " << isosurf->m_ppt3dVertices[i][0] + range[0]
			<< " " << isosurf->m_ppt3dVertices[i][1] + range[2]
			<< " " << isosurf->m_ppt3dVertices[i][2] + range[4]
			<< std::endl;
		is_a = isosurf->m_ppt3dVertices[i][0] + range[0];
		is_b = isosurf->m_ppt3dVertices[i][1] + range[2];
		is_c = isosurf->m_ppt3dVertices[i][2] + range[4];
		/*Displaying the "v" vertices*/
		/*cout << "v " << isosurf->m_ppt3dVertices[i][0] + range[0]
		<< " " << isosurf->m_ppt3dVertices[i][1] + range[2]
		<< " " << isosurf->m_ppt3dVertices[i][2] + range[4]
		<< std::endl;*/

		//Storing the values of vertices to vextex[][]!!!
		vertex[i][0] = is_a;
		vertex[i][1] = is_b;
		vertex[i][2] = is_c;
		//Displaying vertex values.
		//cout << vertex[i][0]<<" ";
		//cout << vertex[i][1]<<" ";
		//cout << vertex[i][2]<< endl;
	}

	for (unsigned int i = 0;
		i < isosurf->getNTriangles(); i++) {
		ofs << "f " << isosurf->m_piTriangleIndices[i * 3] + 1
			<< " " << isosurf->m_piTriangleIndices[i * 3 + 1] + 1
			<< " " << isosurf->m_piTriangleIndices[i * 3 + 2] + 1
			<< std::endl;
		//cout << "f " << isosurf->m_piTriangleIndices[i * 3] + 1
		//	<< " " << isosurf->m_piTriangleIndices[i * 3 + 1] + 1
		//	<< " " << isosurf->m_piTriangleIndices[i * 3 + 2] + 1
		//	<< std::endl;
		face[i][0] = isosurf->m_piTriangleIndices[i * 3];
		face[i][1] = isosurf->m_piTriangleIndices[i * 3 + 1];
		face[i][2] = isosurf->m_piTriangleIndices[i * 3 + 2];
		//Displaying the face values.
		/*	cout << face[i][0] << " ";
		cout << face[i][1] << " ";
		cout << face[i][2] << endl;*/
		lines_faces1++; //return the number of lines in faces!!!
	}

	ofs.close();
	delete isosurf;
	//I just added this to see the screen results.
	//******************************************************************************************Start from Marching Cubes code //******************************************************************************************
	std::cout << "Finished Generation! Please check the generated file: 'Gerald's Heart 3D.obj \n'";
	system("pause");
	return 0;
}

const int nCell = 60;


float f1(float _x, float _y, float _z) {

	//w1[0][7] = -1.693f;
	//w1[1][7] = -0.8463f;
	//w1[2][7] = -1.269f;
	//w1[3][7] = 3.808f;
	//w1[4][7] = 0.4608f;
	//w1[5][7] = -0.03948f;
	//w1[6][7] = -0.204f;

	//w1[0][7] = -1.202f;
	//w1[1][7] = -0.4008f;
	//w1[2][7] = -0.8016f;
	//w1[3][7] = 2.405f;
	//w1[4][7] = 0.3901f;
	//w1[5][7] = -0.1002f;
	//w1[6][7] = -0.02035f;

	float sum = 0.0f;
	int count = 0;
	//cout << n;
	for (int i = 0; i < n; i++) {
		float h_ = charge[i]; //float h_ = aLU[i][n];
		count++;
		float x1 = _x - dv[i][0];
		float y1 = _y - dv[i][1];
		float z1 = _z - dv[i][2];

		if (count == n - 3) {
			x1 = _x;
			y1 = _y;
			z1 = _z;
		}
		if (count == n - 2) {
			x1 = _x;
			y1 = _y;
			z1 = _z;
		}
		if (count == n - 1) {
			x1 = _x;
			y1 = _y;
			z1 = _z;
		}
		if (count == n) {
			x1 = _x;
			y1 = _y;
			z1 = _z;
		}
		sum += D3(x1, y1, z1, h_, count);
	}

	return sum;
}

float D3(float x_, float y_, float z_, float h3, int count3) {
	float lengthSq = sqrt(x_ * x_ + y_ * y_ + z_*z_);
	lengthSq = lengthSq*lengthSq*lengthSq;
	if (count3 == n - 3) {
		lengthSq = 1.0f;
	}
	if (count3 == n - 2) {
		lengthSq = x_;
	}
	if (count3 == n - 1) {
		lengthSq = y_;
	}
	if (count3 == n) {
		lengthSq = z_;
	}
	float tmp = h3*lengthSq;

	return tmp;
}
