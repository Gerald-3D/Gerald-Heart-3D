#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <string>
using namespace std;

const double PI = 3.141592653589793;
const bool ANTICLOCKWISE = true;                           // Traversal of triangles, seen from OUTSIDE

														   //================================================

struct Pt2                                                  // Coordinates of a vector or point
{
	double x, y, z;
};

struct Triangle2                                            // Holds the INDICES and vector area of triangles
{
	int v[3];
	Pt2 area;
	Pt2 normal;
};

Pt2 operator +(Pt2 p, Pt2 q) { return { p.x + q.x, p.y + q.y, p.z + q.z }; }
Pt2 operator -(Pt2 p, Pt2 q) { return { p.x - q.x, p.y - q.y, p.z - q.z }; }
Pt2 operator *(double r, Pt2 p) { return { r * p.x, r * p.y, r * p.z }; }
Pt2 operator *(Pt2 p, double r) { return r * p; }
Pt2 operator /(Pt2 p, double r) { return { p.x / r, p.y / r, p.z / r }; }
double dot(Pt2 p, Pt2 q) { return p.x * q.x + p.y * q.y + p.z * q.z; }
double abs(Pt2 p) { return sqrt(dot(p, p)); }
Pt2 cross(Pt2 p, Pt2 q) { return { p.y * q.z - p.z * q.y, p.z * q.x - p.x * q.z, p.x * q.y - p.y * q.x }; }

ostream &operator << (ostream &strm, Pt2  p) { return strm << p.x << "  " << p.y << "  " << p.z; }
istream &operator >> (istream &strm, Pt2 &p) { return strm >> p.x >> p.y >> p.z; }

//================================================


void readFile(string filename, vector<Pt2> &vertices, vector<Triangle2> &triangles)
{
	vertices.clear();                                       // Comment out if adding to an existing collection
	triangles.clear();                                      //

	string line;

	ifstream in(filename);
	while (getline(in, line))                           // Read whole line
	{
		if (line.find_first_of("vVfF") == string::npos) continue;     // skip pointless lines

		istringstream ss(line);                            // Put line into a stream for input
		string s;
		ss >> s;                                             // Get identifier
		if (s == "v" || s == "V")                          // VERTICES
		{
			Pt2 p;
			ss >> p;
			vertices.push_back(p);
		}
		else if (s == "f" || s == "F")                     // FACES
		{
			string si, sj, sk;
			ss >> si >> sj >> sk;                             // FIRST, read into individual strings
			Triangle2 t;
			t.v[0] = stoi(si) - 1;                          // Get the FIRST integer from each string
			t.v[1] = stoi(sj) - 1;                          // NOTE: subtract 1 because arrays start from 0
			t.v[2] = stoi(sk) - 1;
			triangles.push_back(t);
		}
	}
	in.close();
}


//======================================================================


void calcFaces(const vector<Pt2> &vertices, vector<Triangle2> &triangles)
{
	for (int t = 0; t < triangles.size(); t++)
	{
		int v0 = triangles[t].v[0];                          // Global vertex index
		int v1 = triangles[t].v[1];
		int v2 = triangles[t].v[2];
		Pt2 side1 = vertices[v1] - vertices[v0];              // Side vectors meeting at this vertex
		Pt2 side2 = vertices[v2] - vertices[v0];
		triangles[t].area = 0.5 * cross(side1, side2);     // Triangle vector area is half the cross product of the sides
		if (!ANTICLOCKWISE) triangles[t].area = -1.0 * triangles[t].area;
		double A = abs(triangles[t].area);
		triangles[t].normal = triangles[t].area / A;         // Unit normal vector
	}
}


//================================================


vector<Pt2> calcNormals(const vector<Pt2> &vertices, const vector<Triangle2> &triangles)
{
	vector<Pt2> vnormal(vertices.size(), { 0.0, 0.0, 0.0 });

	for (int t = 0; t < triangles.size(); t++)            // Loop through triangle list
	{
		Pt2 norm = triangles[t].area;
		norm = norm / abs(norm);                           // Unit normal vector for this triangle

		for (int i = 0; i < 3; i++)                        // Update weighted sum at each vertex
		{
			int v0 = triangles[t].v[i];                       // Global vertex index
			int v1 = triangles[t].v[(i + 1) % 3];
			int v2 = triangles[t].v[(i + 2) % 3];
			Pt2 side1 = vertices[v1] - vertices[v0];           // Side vectors meeting at this vertex
			Pt2 side2 = vertices[v2] - vertices[v0];
			//       double weight = acos( dot( side1, side2 ) / ( abs( side1 ) * abs( side2 ) ) );   // Angle enclosed at this vertex
			double weight = 1.0;                              // Use this if you want unweighted averages
			vnormal[v0] = vnormal[v0] + weight * norm;        // Contribution to normal vector
		}
	}

	for (int v = 0; v < vertices.size(); v++)
	{
		vnormal[v] = vnormal[v] / abs(vnormal[v]);         // Normalise to unit length
	}

	return vnormal;
}


//================================================


void output(ostream &out, const vector<Pt2> &vertices, const vector<Pt2> &vnormal)
{
	int N = vertices.size();

	// Formatting (adapt to your needs)
	out.setf(ios::fixed);                  // Fixed or scientific
	out.precision(6);                      // Decimal digits after point
#define SP << " " << setw( 12 ) <<       // Spacer and field width

	for (int i = 0; i < N; i++)
	{
		out SP i
			SP vertices[i].x SP vertices[i].y SP vertices[i].z
			SP vnormal[i].x SP vnormal[i].y SP vnormal[i].z << '\n';
	}
}


//================================================


void summary(const vector<Pt2> &vertices, const vector<Triangle2> &triangles)
{
	//temp cout << "\nVertices: " << vertices.size() << '\n';
	for (int i = 0; i < vertices.size(); i++)
	{
		//tempcout << i << ": " << vertices[i] << '\n';
	}

	//tempcout << "\nTriangles: " << triangles.size() << '\n';
	for (int t = 0; t < triangles.size(); t++)
	{
		//tempcout << t << ": ";
		for (int i = 0; i < 3; i++)
		{
			//tempcout << triangles[t].v[i] << " ";
		}
		//tempcout << triangles[t].normal << '\n';
	}
}


//================================================


//int main()
//{
//	string filename = "C:/Users/user/Downloads/Love+OBJ/Love.obj";
//	vector<Pt2> vertices;
//	vector<Triangle2> triangles;
//
//	readFile(filename, vertices, triangles);                   // Read //vertices and triangles
//	calcFaces(vertices, triangles);                            // Calculate //area vectors for triangles
//	summary(vertices, triangles);                              // Check
//
//	vector<Pt> vnormal = calcNormals(vertices, triangles);     // Calculate //normals at vertices
//	cout << "\nVertices and vertex normals:\n";
//	output(cout, vertices, vnormal);
//	system("pause");
//}

//================================================  