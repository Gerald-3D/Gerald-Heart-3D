#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

struct Point { double x, y, z; };       // Spatial coordinates

struct Triangle { int i, j, k; };       // Vertex numbers for a triangle

										//======================================================================


void getFacesAndVertices(string filename, vector<Point> &vertices, vector<Triangle> &faces)
{
	faces.clear();   vertices.clear();                      // comment out to add to an existing collection

	string line;
	char c;
	int i, j, k;
	double x, y, z;
	string si, sj, sk;

	ifstream in(filename);
	while (getline(in, line))                           // read whole line
	{
		if (line.find_first_of("vVnNfF") == string::npos) continue;     // skip pointless lines

		istringstream ss(line);                            // put line into a stream for input
		ss >> c;                                             // get first character
		switch (c)
		{
		case 'v':                                         // VERTICES
		case 'V':                                         //    (either case)
			ss >> x >> y >> z;                             // read from internal stream
			vertices.push_back({ x, y, z });             // add to vector
			break;
		case 'n':                                         // VERTICES NORMALS
		case 'N':
			break;
		case 'f':                                         // FACES
		case 'F':                                         //    (either case)
			ss >> si >> sj >> sk;                          // FIRST, read into individual strings
			i = stoi(si);  j = stoi(sj);  k = stoi(sk);  // Get the FIRST integer from each string
			faces.push_back({ i, j, k });                // add to vector
			break;
		default:
			break;
		}
	}
	in.close();
}


//======================================================================

//int main()
//{
//
//	return 0;
//	//vector<Point> vertices;
//	//vector<Triangle> faces;
//	//string filename = "C:/Users/user/Downloads/armadillo/armadillo1.obj"; //string filename = "file.OBJ";
//
//	//getFacesAndVertices(filename, vertices, faces);
//
//	//cout << "Vertices:\n";
//	//for (Point p : vertices) cout << p.x << "  " << p.y << "  " << p.z << '\n';
//
//	//cout << "\n\n";
//
//	//cout << "Triangles\n";
//	//for (Triangle t : faces) cout << t.i << "  " << t.j << "  " << t.k << '\n';
//	//system("pause");
//}